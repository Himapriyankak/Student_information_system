package com.techpalle;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.techpalle.DAO.DataAcess;

@WebServlet("/Login")
public class AdminLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
    public AdminLoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// below code is to verify if data is coming from Html page.
		PrintWriter pw = response.getWriter();
		String email = request.getParameter("email");
		String password =  request.getParameter("pw");
		pw.println(email);
		pw.println(password);
		
		// verification is over.
		boolean result = DataAcess.checkAdmin(email, password);
		if(result==true) {
			response.sendRedirect("Welcome.jsp");
			pw.println("LOGIN SUCCESS");
		}
		else {
			pw.println("LOGIN FAILED");
		}
	}

}
