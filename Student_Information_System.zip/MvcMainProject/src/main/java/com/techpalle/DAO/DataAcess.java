package com.techpalle.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.techpalle.model.Student;

public class DataAcess {
	public static ArrayList<Student>getStudent(){
		ArrayList<Student>a1=new ArrayList<Student>();//empty arraylist
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/j2eeproject","root","admin");
			Statement  s = c.createStatement();
		ResultSet rs =	s.executeQuery("select*from student");
		while(rs.next()) {
			int sno = rs.getInt(1);
			String sname = rs.getString(2);
			String course= rs.getString(3);
			String gender = rs.getString(4);
			String email  =rs.getString (5);
			
			Student s1 = new Student(sno, sname, course, gender, email);
			a1.add(s1);
		}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return a1;
		
	}
	public static void insertStudent(String name,String course,String gender,String email) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/j2eeproject","root","admin");
			PreparedStatement s = c.prepareStatement("insert into Student(sname,course,gender,email)values(?,?,?,?)");
			s.setString(1,name);
			s.setString(2,course);
			s.setString(3,gender);
			s.setString(4,email);			
			s.executeUpdate();
			s.close();
			c.close();
			} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
  public static boolean checkAdmin(String email,String password) {
	  //JDBC Code read all rows from admin table
	  try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/j2eeproject","root","admin");
	Statement s = c.createStatement();
	
	ResultSet rs = s.executeQuery("select * from admin ");
	int count =0;
	if(rs!=null) {
		while(rs.next()==true) {
			String dbemail=rs.getString(2);
			String dbpw = rs.getString(3);
			if(dbemail.equals(email)&&dbpw.equals(password)) {
				count++;
				break;
			}
		}
	}
	if(count==1) {
		return true;
	}
	else {
		return false;
	}
	
	} catch (ClassNotFoundException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	  return false;//admin login failure
  }
}
